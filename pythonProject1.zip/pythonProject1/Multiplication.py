from selenium import webdriver
from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.common.keys import keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

S = Service ("C:\webdriver\chromedriver.exe")

driver: WebDriver = webdriver.Chrome(service=S)
driver.get("https://www.calculator.net/")

driver.find_element_by_xpath("//*[@id='sciout']/tbody/tr[2]/td[2]/div/div[2]/span[1]").click()  #4
driver.find_element_by_xpath("//*[@id='sciout']/tbody/tr[2]/td[2]/div/div[3]/span[2]").click()  #2
driver.find_element_by_xpath("//*[@id='sciout']/tbody/tr[2]/td[2]/div/div[3]/span[3]").click()  #3

driver.find_element_by_xpath("//*[@id='sciout']/tbody/tr[2]/td[2]/div/div[3]/span[4]").click()  #Multiplication

driver.find_element_by_xpath("//*[@id='sciout']/tbody/tr[2]/td[2]/div/div[2]/span[2]").click()  #5
driver.find_element_by_xpath("//*[@id='sciout']/tbody/tr[2]/td[2]/div/div[3]/span[2]").click()  #2
driver.find_element_by_xpath("//*[@id='sciout']/tbody/tr[2]/td[2]/div/div[2]/span[2]").click()  #5

driver.find_element_by_xpath("//*[@id='sciout']/tbody/tr[2]/td[2]/div/div[5]/span[4]").click()  #=
